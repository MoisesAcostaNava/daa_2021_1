import xlrd
from arrays import Array3D
def main():
    a3=Array3D(34,33,14)
    for anio in range(1985,2019):
        ruta='./Precipitacion/'+str(anio)+'Precip.xls'
        archivo=xlrd.open_workbook(filename=ruta)
        hoja=archivo.sheet_by_index(0)
        for r in range(1,34):
            for c in range(0,14):
                a3.set_item(anio-1985,r-1,c,hoja.cell_value(r,c))

    #Tarea 1 mes-estado-año COMPLETO
    a=int(input('Año (1985-2018): '))
    e=int(input('Edo (1-32): '))
    m=int(input('Mes (1-12): '))
    print('En',a3.get_item(0,e,0),'hubo un promedio de',a3.get_item(a-1985,e,m),'en el mes de',a3.get_item(0,0,m))
    #Tarea 2 estado-mes COMPLETO
    e=int(input('Edo (1-32): '))
    m=int(input('Mes (1-12): '))
    promedio=0
    for anio in range(0,34):
        promedio+=a3.get_item(anio,e,m)
    print('El promedio para',a3.get_item(0,e,0),'de 1985 a 2018 es:',round(promedio/34,2))

    #Tarea 3 Estado COMPLETO
    promedio=0
    e=int(input('Edo (1-32): '))
    print(a3.get_item(0,e,0))
    for anio in range(0,34):
        print('Año',anio+1985)
        for mes in range(1,13):
            print('Mes',a3.get_item(0,0,mes),'=   ',round(a3.get_item(anio,e,mes),2))
            promedio+=a3.get_item(anio,e,mes)
        print('-----------------------------------------------')
    print('El promedio para',a3.get_item(0,e,0),'de 1985 a 2018 es:',round(promedio/(34*12),2))
    #Tarea 4 Promedio Total COMPLETO
    promedio=0
    for anio in range(0,34):
        for estado in range(1,33):
            for mes in range(1,13):
                promedio+=a3.get_item(anio,estado,mes)
    promedio/=(34*12*32)
    print('El promedio total de lluvias en México de 1985 a 2018 es:',round(promedio,2))
                
        
            
main()
