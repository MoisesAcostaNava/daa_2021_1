class Array3D:
    def __init__(self,depth,rows,cols):
        self.__depth=depth
        self.__rows=rows
        self.__cols=cols
        self.__arreglo=[[[0 for k in range(cols)] for j in range(rows)]for i in range(depth)]
    
    def get_num_depth(self):
        return self.__depth

    def get_num_rows(self):
        return self.__rows

    def get_num_cols(self):
        return self.__cols

    def get_item(self,depth,rows,cols):
        return self.__arreglo[depth][rows][cols]

    def set_item(self,depth,rows,cols,value):
        self.__arreglo[depth][rows][cols]=value

    def clearing(self,value):
        for i in range(self.__depth):
            for j in range(self.__rows):
                for k in range(self.__cols):
                    self.__arreglo[i][j][k]=value

    def to_string(self):
        capa=1
        for layer in self.__arreglo:
            print('----Capa',capa,'----')
            for ren in layer:
                print(ren)
            capa+=1
        print()
                
